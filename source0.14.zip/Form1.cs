﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace webbrowserbuild0._12n
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			webframe.GoBack();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			webframe.GoForward();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			webframe.Navigate(urltext.Text);
		}

        private void urltext_TextChanged(object sender, EventArgs e)
        {

        }

        private void webframe_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
			
		}

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
			webframe.GoBack();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
			webframe.GoForward();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
			
		}

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
			MessageBox.Show("From the Opsec Corporation, comes Opsec Browser, The browser better than any other browser. Originally made as a joke for CollabVM, Opsec Browser is now a full-time project, We hope you enjoy Opsec Browser as much as we did developing it.");
		}

        private void pictureBox4_Click(object sender, EventArgs e)
        {
			webframe.Navigate("https://collabvmdl.desktopgooose.repl.co/opsec.html");
		}

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.ShowDialog();
		}

        private void pictureBox6_Click(object sender, EventArgs e)
        {
			webframe.Refresh();
		}

        private void pictureBox7_Click(object sender, EventArgs e)
        {
			webframe.Navigate("https://collabvmdl.desktopgooose.repl.co/e.html");
		}
    }
}
